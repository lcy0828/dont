package mod

import (
	"dont/models"
	"fmt"
	"github.com/gin-gonic/gin"
	"github.com/gocolly/colly"
	"github.com/gocolly/colly/proxy"
	"log"
	"time"
)

// 获取多个文章标签
//func SearchMod(c *gin.Context) {
//	url := "https://steamcommunity.com/workshop/browse/?appid=322330&searchtext=123&browsesort=trend&section=readytouseitems&created_date_range_filter_start=0&created_date_range_filter_end=0&updated_date_range_filter_start=0&updated_date_range_filter_end=0&actualsort=trend&p=1&days=-1"
//}

func SearchMod(g *gin.Context) {
	// Instantiate default collector
	c := colly.NewCollector(
		// Visit only domains: hackerspaces.org, wiki.hackerspaces.org
		colly.AllowedDomains("hackerspaces.org", "wiki.hackerspaces.org"),
	)
	if p, err := proxy.RoundRobinProxySwitcher(
		"socks5://127.0.0.1:1080",
		//"socks5://127.0.0.1:1338",
		"http://127.0.0.1:1087",
	); err == nil {
		c.SetProxyFunc(p)
	}
	// On every a element which has href attribute call callback
	c.OnHTML("a[href]", func(e *colly.HTMLElement) {
		link := e.Attr("href")
		// Print link
		fmt.Printf("Link found: %q -> %s\n", e.Text, link)
		// Visit link found on page
		// Only those links are visited which are in AllowedDomains
		c.Visit(e.Request.AbsoluteURL(link))
	})

	// Before making a request print "Visiting ..."
	c.OnRequest(func(r *colly.Request) {
		fmt.Println("Visiting", r.URL.String())
	})

	// Start scraping on https://hackerspaces.org
	//c.Visit("https://hackerspaces.org/")
	// Start scraping on https://hackerspaces.org
	c.Visit("https://steamcommunity.com/workshop/browse/?appid=322330&searchtext=123&browsesort=trend&section=readytouseitems&created_date_range_filter_start=0&created_date_range_filter_end=0&updated_date_range_filter_start=0&updated_date_range_filter_end=0&actualsort=trend&p=1&days=-1")
}
func AddMod(g *gin.Context) {
	//
	url := "https://workshop8.abcvg.info/archive/322330/1392778117.zip"
	fileName := "1392778117.zip"
	start := time.Now()
	d := models.NewDownloader(url, fileName, "", 5)
	if err := d.Download(); err != nil {
		log.Fatal(err)
	}
	log.Printf("下载%v 耗时：%v s", fileName, time.Since(start).Seconds())
}

func DownloadMod(g *gin.Context) {

}
